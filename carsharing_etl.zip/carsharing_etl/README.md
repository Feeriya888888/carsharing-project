# Carsharing ETL Pipeline — проект для Data Engineer

ETL-пайплайн для обработки данных о поездках каршеринга. Проект имитирует реальный рабочий процесс Data Engineer: ежедневная загрузка «сырых» данных, очистка, обогащение, агрегация и запись в хранилище (SQLite как имитация DWH).

## Бизнес-сценарий

Каршеринговая компания ежедневно получает логи поездок от парка автомобилей (CSV-файлы). Задача инженера:

1. **Extract** — забрать «сырой» CSV-файл за прошедшие сутки.
2. **Transform** — очистить данные, убрать аномалии, рассчитать производные метрики (длительность поездки, стоимость).
3. **Load** — загрузить в хранилище: витрина детальных поездок + витрина суточной агрегации.
4. **Quality Check** — проверить полноту и корректность данных после загрузки.

## Стек

| Компонент | Технология |
|---|---|
| Язык | Python 3.10+ |
| Хранилище | SQLite (имитация DWH: можно заменить на PostgreSQL/BigQuery) |
| Формат данных | CSV → pandas DataFrame → SQLite |
| Оркестрация | cron / Airflow-совместимая структура |
| Тесты | pytest |
| Логирование | Python `logging` |

## Структура проекта

```
carsharing_etl/
├── config/
│   └── settings.yaml          # Конфигурация (пути, параметры)
├── data/
│   ├── raw/                   # Сырые CSV (вход пайплайна)
│   │   └── trips_2026_09_30.csv
│   └── processed/             # Очищенные данные (промежуточный слой)
├── src/
│   ├── extract/
│   │   └── extractor.py       # Извлечение CSV
│   ├── transform/
│   │   └── transformer.py     # Очистка, обогащение, расчёты
│   ├── load/
│   │   └── loader.py          # Загрузка в SQLite
│   ├── utils/
│   │   ├── logger.py          # Настройка логирования
│   │   └── db.py              # Подключение к БД
│   └── pipeline.py            # Главный оркестратор ETL
├── tests/
│   └── test_pipeline.py       # Тесты
├── scripts/
│   └── generate_sample_data.py  # Генерация тестовых данных
├── requirements.txt
├── .gitignore
└── README.md
```

## ER-диаграмма хранилища

```mermaid
erDiagram
    FACT_TRIPS {
        int trip_id PK
        datetime start_time
        datetime end_time
        int duration_minutes
        float distance_km
        float total_cost
        str car_id
        str user_id
        str status
    }

    DIM_CARS {
        str car_id PK
        str model
        str license_plate
        int year
    }

    DIM_USERS {
        str user_id PK
        str user_name
        str tier
    }

    AGG_DAILY_TRIPS {
        date trip_date PK
        int total_trips
        float total_revenue
        float avg_duration
        float avg_distance
    }

    DIM_CARS ||--|{ FACT_TRIPS : "performs"
    DIM_USERS ||--|{ FACT_TRIPS : "makes"
```

## Как запустить

### 1. Установить зависимости

```bash
pip install -r requirements.txt
```

### 2. Сгенерировать тестовые данные

```bash
python scripts/generate_sample_data.py
```

Это создаст `data/raw/trips_2026_09_30.csv` — синтетический лог поездок с мусорными строками и аномалиями (имитация реального «сырого» файла).

### 3. Запустить пайплайн

```bash
python -m src.pipeline
```

Или с параметрами:

```bash
python -m src.pipeline --date 2026-09-30
```

### 4. Проверить результат

```bash
sqlite3 data/warehouse.db "SELECT * FROM agg_daily_trips;"
```

### 5. Запустить тесты

```bash
pytest tests/ -v
```

## Что демонстрирует проект

| Навык | Где реализован |
|---|---|
| ETL-проектирование | `src/extract/`, `src/transform/`, `src/load/` |
| Очистка и валидация данных | `transformer.py`: удаление дубликатов, проверка диапазонов, обработка NULL |
| Моделирование DWH | Звёздная схема: `fact_trips`, `dim_cars`, `dim_users`, `agg_daily_trips` |
| Data Quality | Проверки после загрузки: row count, NULL-проверка, диапазон стоимости |
| Оркестрация | `pipeline.py` — последовательный запуск этапов с обработкой ошибок |
| Логирование | Структурированные логи на каждый этап (INFO/WARNING/ERROR) |
| Тестирование | `pytest` с фикстурами, проверка трансформаций |
| Воспроизводимость | `requirements.txt`, `config/settings.yaml`, скрипт генерации данных |
| Документация | README, ER-диаграмма, комментарии в коде |

## Масштабирование на продакшен

- **Хранилище**: заменить SQLite на PostgreSQL / BigQuery / Snowflake.
- **Оркестрация**: обернуть `pipeline.py` в Airflow DAG.
- **Источники данных**: заменить чтение CSV на API (REST/GraphQL) или CDC (Kafka).
- **Мониторинг**: добавить алерты при падении пайплайна (Slack/Telegram webhook).
- **Регистрация**: добавить lineage-трекинг (OpenLineage / Apache Atlas).
