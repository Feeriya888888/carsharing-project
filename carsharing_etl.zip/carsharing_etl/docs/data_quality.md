# Data Quality Checks

## Проверки после загрузки

| # | Проверка | Метод | Действие при FAIL |
|---|---|---|---|
| 1 | Row count > 0 | `SELECT COUNT(*)` | Пайплайн падает, алерт |
| 2 | NULL в ключевых полях | `SUM(CASE WHEN ... IS NULL)` | Warning в лог, пайплайн продолжает |
| 3 | Диапазон стоимости | `MIN/MAX(total_cost)` | Логирование, ручная проверка |

## Расширение проверок (roadmap)

- Уникальность `trip_id` (PRIMARY KEY constraint)
- Referential integrity: каждый `car_id` из `fact_trips` есть в `dim_cars`
- Freshness: дата в данных соответствует ожидаемой дате загрузки
- Volume vs вчера: отклонение ±50% — алерт
