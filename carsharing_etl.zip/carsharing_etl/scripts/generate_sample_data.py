"""Генератор синтетических данных для тестирования ETL."""
import pandas as pd
import numpy as np
import os
from datetime import datetime, timedelta

def generate_trips(n_rows: int = 500, date_str: str = "2026_09_30") -> str:
    """Создаёт CSV с поездками, включая мусорные строки и аномалии."""
    np.random.seed(42)

    start_base = datetime(2026, 9, 30, 6, 0, 0)
    car_ids = [f"CAR{str(i).zfill(3)}" for i in range(1, 6)]
    user_ids = [f"USR{str(i).zfill(3)}" for i in range(1, 6)]
    statuses = ["completed", "completed", "completed", "completed", "cancelled"]

    rows = []
    for i in range(1, n_rows + 1):
        start = start_base + timedelta(
            hours=np.random.randint(0, 18),
            minutes=np.random.randint(0, 59)
        )
        duration_min = np.random.exponential(35)
        end = start + timedelta(minutes=duration_min)
        distance = max(0.1, np.random.exponential(12))

        rows.append({
            "trip_id": i,
            "car_id": np.random.choice(car_ids),
            "user_id": np.random.choice(user_ids),
            "start_time": start.strftime("%Y-%m-%d %H:%M:%S"),
            "end_time": end.strftime("%Y-%m-%d %H:%M:%S"),
            "distance_km": round(distance, 2),
            "start_lat": round(47.2 + np.random.uniform(-0.05, 0.05), 6),
            "start_lon": round(38.9 + np.random.uniform(-0.05, 0.05), 6),
            "end_lat": round(47.2 + np.random.uniform(-0.05, 0.05), 6),
            "end_lon": round(38.9 + np.random.uniform(-0.05, 0.05), 6),
            "status": np.random.choice(statuses),
        })

    df = pd.DataFrame(rows)

    # Добавляем мусор: дубликаты
    df = pd.concat([df, df.sample(20)], ignore_index=True)

    # Добавляем мусор: пустые car_id
    df.loc[df.sample(10).index, "car_id"] = None

    # Добавляем мусор: некорректные даты
    df.loc[df.sample(5).index, "start_time"] = "INVALID"

    # Добавляем аномалии: огромная дистанция
    df.loc[df.sample(3).index, "distance_km"] = 5000

    # Добавляем аномалии: нулевая дистанция
    df.loc[df.sample(5).index, "distance_km"] = 0.0

    # Перемешиваем
    df = df.sample(frac=1).reset_index(drop=True)

    os.makedirs("data/raw", exist_ok=True)
    file_path = f"data/raw/trips_{date_str}.csv"
    df.to_csv(file_path, index=False)
    print(f"Создан файл: {file_path} ({len(df)} строк, включая мусор)")
    return file_path

if __name__ == "__main__":
    generate_trips()
