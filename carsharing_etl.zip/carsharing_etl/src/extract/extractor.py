"""Этап EXTRACT: чтение сырых данных о поездках."""
import pandas as pd
import os
from src.utils.logger import setup_logger

logger = setup_logger("extractor")

def extract_csv(file_path: str) -> pd.DataFrame:
    """Читает сырой CSV-файл с логами поездок.

    Ожидаемые колонки:
        trip_id, car_id, user_id, start_time, end_time,
        distance_km, start_lat, start_lon, end_lat, end_lon, status

    Возвращает DataFrame с сырыми данными (без очистки).
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Сырой файл не найден: {file_path}")

    logger.info(f"Чтение файла: {file_path}")
    df = pd.read_csv(file_path)

    logger.info(f"Загружено строк: {len(df)}")
    logger.info(f"Колонки: {list(df.columns)}")
    return df
