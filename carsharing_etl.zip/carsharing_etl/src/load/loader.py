"""Этап LOAD: запись в хранилище (SQLite)."""
import pandas as pd
from src.utils.db import get_connection
from src.utils.logger import setup_logger

logger = setup_logger("loader")

def load_to_warehouse(
    df_fact: pd.DataFrame,
    df_dim_cars: pd.DataFrame,
    df_dim_users: pd.DataFrame,
    df_agg: pd.DataFrame,
    db_path: str,
    config: dict
):
    """Загружает все таблицы в SQLite."""
    tables = config["tables"]
    conn = get_connection(db_path)
    try:
        logger.info("=== LOAD ===")

        # Перезаписываем таблицы (в проде — upsert/merge)
        df_dim_cars.to_sql(tables["dim_cars"], conn, if_exists="replace", index=False)
        logger.info(f"dim_cars: {len(df_dim_cars)} строк")

        df_dim_users.to_sql(tables["dim_users"], conn, if_exists="replace", index=False)
        logger.info(f"dim_users: {len(df_dim_users)} строк")

        df_fact.to_sql(tables["fact_trips"], conn, if_exists="replace", index=False)
        logger.info(f"fact_trips: {len(df_fact)} строк")

        df_agg.to_sql(tables["agg_daily_trips"], conn, if_exists="replace", index=False)
        logger.info(f"agg_daily_trips: {len(df_agg)} строк")

        logger.info(f"Загрузка завершена. Хранилище: {db_path}")
    finally:
        conn.close()

def run_quality_checks(db_path: str, config: dict) -> bool:
    """Data Quality проверки после загрузки."""
    from src.utils.db import execute_query
    tables = config["tables"]
    logger.info("=== DATA QUALITY CHECKS ===")
    all_passed = True

    # 1. Проверка row count
    for table_name in tables.values():
        df = execute_query(db_path, f"SELECT COUNT(*) as cnt FROM {table_name}")
        count = df["cnt"].iloc[0]
        status = "PASS" if count > 0 else "FAIL"
        if count == 0:
            all_passed = False
        logger.info(f"[{status}] {table_name}: {count} строк")

    # 2. NULL-проверка fact_trips
    df = execute_query(db_path, f"""
        SELECT
            SUM(CASE WHEN trip_id IS NULL THEN 1 ELSE 0 END) as null_trip_id,
            SUM(CASE WHEN start_time IS NULL THEN 1 ELSE 0 END) as null_start_time,
            SUM(CASE WHEN total_cost IS NULL THEN 1 ELSE 0 END) as null_cost
        FROM {tables['fact_trips']}
    """)
    nulls = df.iloc[0]
    for col, val in nulls.items():
        if val > 0:
            logger.warning(f"[WARN] NULL в {col}: {val}")
            all_passed = False

    # 3. Диапазон стоимости
    df = execute_query(db_path, f"""
        SELECT MIN(total_cost) as min_cost, MAX(total_cost) as max_cost
        FROM {tables['fact_trips']}
    """)
    min_cost = df["min_cost"].iloc[0]
    max_cost = df["max_cost"].iloc[0]
    logger.info(f"[INFO] Диапазон стоимости: {min_cost} - {max_cost}")

    if all_passed:
        logger.info("Все проверки пройдены!")
    else:
        logger.error("Есть провалы в проверках!")
    return all_passed
