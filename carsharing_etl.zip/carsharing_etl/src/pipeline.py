"""Главный оркестратор ETL-пайплайна."""
import argparse
import yaml
import os
import sys
from datetime import datetime, timedelta

from src.utils.logger import setup_logger
from src.extract.extractor import extract_csv
from src.transform.transformer import (
    transform, build_dim_cars, build_dim_users, build_agg_daily
)
from src.load.loader import load_to_warehouse, run_quality_checks

logger = setup_logger("pipeline")

def load_config(config_path: str = "config/settings.yaml") -> dict:
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def run_pipeline(date_str: str = None, config_path: str = "config/settings.yaml"):
    """Запуск полного ETL-пайплайна."""
    logger.info("=" * 60)
    logger.info("Запуск Carsharing ETL Pipeline")
    logger.info("=" * 60)

    # 1. Загрузка конфигурации
    config = load_config(config_path)
    logger.info("Конфигурация загружена")

    # 2. Определение пути к сырым данным
    if date_str is None:
        date_str = (datetime.now() - timedelta(days=1)).strftime("%Y_%m_%d")
    raw_file = os.path.join(
        config["raw_data_dir"],
        f"trips_{date_str}.csv"
    )
    logger.info(f"Обработка файла: {raw_file}")

    # 3. EXTRACT
    try:
        df_raw = extract_csv(raw_file)
    except FileNotFoundError as e:
        logger.error(str(e))
        logger.info("Запустите: python scripts/generate_sample_data.py")
        sys.exit(1)

    # 4. TRANSFORM
    df_clean = transform(df_raw, config)
    if df_clean.empty:
        logger.warning("После трансформации нет данных. Завершение.")
        return

    # Сохранение обработанных данных (промежуточный слой)
    processed_path = os.path.join(
        config["processed_data_dir"],
        f"trips_{date_str}_clean.csv"
    )
    df_clean.to_csv(processed_path, index=False)
    logger.info(f"Очищенные данные сохранены: {processed_path}")

    # Построение витрин
    df_dim_cars = build_dim_cars(df_clean)
    df_dim_users = build_dim_users(df_clean)
    df_agg = build_agg_daily(df_clean)

    # 5. LOAD
    db_path = config["warehouse_path"]
    load_to_warehouse(
        df_clean, df_dim_cars, df_dim_users, df_agg, db_path, config
    )

    # 6. DATA QUALITY
    passed = run_quality_checks(db_path, config)
    if not passed:
        logger.error("Пайплайн завершён с ошибками качества данных!")
        sys.exit(2)

    logger.info("=" * 60)
    logger.info("Пайплайн успешно завершён!")
    logger.info("=" * 60)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Carsharing ETL Pipeline")
    parser.add_argument(
        "--date",
        type=str,
        default=None,
        help="Дата обработки в формате YYYY_MM_DD (по умолчанию вчера)"
    )
    args = parser.parse_args()
    run_pipeline(date_str=args.date)
