"""Этап TRANSFORM: очистка, валидация, обогащение."""
import pandas as pd
import numpy as np
from src.utils.logger import setup_logger

logger = setup_logger("transformer")

def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Базовая очистка: удаление дубликатов, пустых строк, приведение типов."""
    initial_count = len(df)
    df = df.drop_duplicates(subset=["trip_id"])
    df = df.dropna(subset=["trip_id", "car_id", "user_id", "start_time", "end_time"])
    logger.info(f"Очистка: {initial_count} -> {len(df)} строк (удалено {initial_count - len(df)})")
    return df

def parse_datetime(df: pd.DataFrame) -> pd.DataFrame:
    """Преобразует строковые даты в datetime."""
    df["start_time"] = pd.to_datetime(df["start_time"], errors="coerce")
    df["end_time"] = pd.to_datetime(df["end_time"], errors="coerce")

    invalid_dates = df[df["start_time"].isna() | df["end_time"].isna()]
    if len(invalid_dates) > 0:
        logger.warning(f"Некорректные даты: {len(invalid_dates)} строк удалено")
        df = df.dropna(subset=["start_time", "end_time"])
    return df

def calculate_duration(df: pd.DataFrame) -> pd.DataFrame:
    """Вычисляет длительность поездки в минутах."""
    df["duration_minutes"] = (df["end_time"] - df["start_time"]).dt.total_seconds() / 60
    df["duration_minutes"] = df["duration_minutes"].round(2)
    return df

def calculate_cost(df: pd.DataFrame, base_rate: float = 15.0) -> pd.DataFrame:
    """Рассчитывает стоимость поездки: base_rate руб/мин + 8 руб/км."""
    df["total_cost"] = (
        df["duration_minutes"] * base_rate + df["distance_km"] * 8.0
    ).round(2)
    return df

def validate_ranges(
    df: pd.DataFrame,
    config: dict
) -> pd.DataFrame:
    """Фильтрует аномальные значения по заданным порогам."""
    v = config["validation"]
    before = len(df)

    df = df[
        (df["duration_minutes"] >= v["min_trip_duration_minutes"]) &
        (df["duration_minutes"] <= v["max_trip_duration_minutes"])
    ]
    df = df[
        (df["distance_km"] >= v["min_distance_km"]) &
        (df["distance_km"] <= v["max_distance_km"])
    ]
    df = df[df["total_cost"] >= v["min_cost"]]

    logger.info(f"Валидация диапазонов: {before} -> {len(df)} (отфильтровано {before - len(df)})")
    return df

def transform(df: pd.DataFrame, config: dict) -> pd.DataFrame:
    """Полный пайплайн трансформации."""
    logger.info("=== TRANSFORM ===")
    df = clean_data(df)
    df = parse_datetime(df)
    df = calculate_duration(df)
    df = calculate_cost(df)
    df = validate_ranges(df, config)
    df = df.reset_index(drop=True)
    logger.info(f"Итог трансформации: {len(df)} строк")
    return df

def build_dim_cars(df: pd.DataFrame) -> pd.DataFrame:
    """Создаёт измерение автомобилей."""
    models = ["Toyota Camry", "Kia Rio", "VW Polo", "Hyundai Solaris", "Lada Vesta"]
    plates = [f"А{100+i}ВС77" for i in range(len(models))]
    years = [2021, 2022, 2020, 2023, 2022]
    dim = pd.DataFrame({
        "car_id": sorted(df["car_id"].unique()),
    })
    dim["model"] = dim["car_id"].rank(method="min").astype(int).map(
        dict(enumerate(models, 1))
    )
    dim["license_plate"] = dim["car_id"].rank(method="min").astype(int).map(
        dict(enumerate(plates, 1))
    )
    dim["year"] = dim["car_id"].rank(method="min").astype(int).map(
        dict(enumerate(years, 1))
    )
    return dim

def build_dim_users(df: pd.DataFrame) -> pd.DataFrame:
    """Создаёт измерение пользователей."""
    names = ["Иван П.", "Анна С.", "Дмитрий К.", "Мария Л.", "Сергей В."]
    tiers = ["standard", "premium", "standard", "premium", "business"]
    dim = pd.DataFrame({
        "user_id": sorted(df["user_id"].unique()),
    })
    dim["user_name"] = dim["user_id"].rank(method="min").astype(int).map(
        dict(enumerate(names, 1))
    )
    dim["tier"] = dim["user_id"].rank(method="min").astype(int).map(
        dict(enumerate(tiers, 1))
    )
    return dim

def build_agg_daily(df: pd.DataFrame) -> pd.DataFrame:
    """Создаёт суточную агрегацию по поездкам."""
    df["trip_date"] = df["start_time"].dt.date
    agg = df.groupby("trip_date").agg(
        total_trips=("trip_id", "count"),
        total_revenue=("total_cost", "sum"),
        avg_duration=("duration_minutes", "mean"),
        avg_distance=("distance_km", "mean"),
    ).reset_index()
    agg["total_revenue"] = agg["total_revenue"].round(2)
    agg["avg_duration"] = agg["avg_duration"].round(2)
    agg["avg_distance"] = agg["avg_distance"].round(2)
    return agg
