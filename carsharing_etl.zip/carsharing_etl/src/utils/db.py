"""Утилиты для работы с SQLite (имитация DWH)."""
import sqlite3
import pandas as pd
from typing import Optional

def get_connection(db_path: str) -> sqlite3.Connection:
    """Создаёт подключение к SQLite."""
    return sqlite3.connect(db_path)

def execute_query(db_path: str, query: str) -> Optional[pd.DataFrame]:
    """Выполняет SQL-запрос и возвращает DataFrame."""
    conn = get_connection(db_path)
    try:
        return pd.read_sql_query(query, conn)
    finally:
        conn.close()

def table_exists(db_path: str, table_name: str) -> bool:
    """Проверяет, существует ли таблица."""
    conn = get_connection(db_path)
    try:
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
            (table_name,)
        )
        return cursor.fetchone() is not None
    finally:
        conn.close()
