"""Тесты для ETL-пайплайна."""
import pytest
import pandas as pd
import numpy as np
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.transform.transformer import (
    clean_data, parse_datetime, calculate_duration, calculate_cost, transform
)

@pytest.fixture
def sample_config():
    return {
        "validation": {
            "min_trip_duration_minutes": 1,
            "max_trip_duration_minutes": 1440,
            "min_distance_km": 0.1,
            "max_distance_km": 1000,
            "min_cost": 0,
            "max_cost": 100000,
        },
        "tables": {
            "fact_trips": "fact_trips",
            "dim_cars": "dim_cars",
            "dim_users": "dim_users",
            "agg_daily_trips": "agg_daily_trips",
        }
    }

@pytest.fixture
def sample_raw_data():
    """Сырые данные с мусором, дубликатами и аномалиями."""
    return pd.DataFrame({
        "trip_id": [1, 2, 3, 1, 4, 5, 6],
        "car_id": ["CAR001", "CAR002", "CAR003", "CAR001", "CAR004", "CAR005", None],
        "user_id": ["USR001", "USR002", "USR003", "USR001", "USR004", "USR005", "USR006"],
        "start_time": [
            "2026-09-30 08:00:00", "2026-09-30 09:30:00",
            "2026-09-30 10:00:00", "2026-09-30 08:00:00",
            "2026-09-30 11:00:00", "invalid_date",
            "2026-09-30 12:00:00"
        ],
        "end_time": [
            "2026-09-30 08:45:00", "2026-09-30 10:15:00",
            "2026-09-30 10:30:00", "2026-09-30 08:45:00",
            "2026-09-30 12:00:00", "2026-09-30 11:30:00",
            "2026-09-30 12:30:00"
        ],
        "distance_km": [15.0, 25.5, 8.2, 15.0, 0.0, 12.0, 18.0],
    })

class TestCleanData:
    def test_removes_duplicates(self, sample_raw_data):
        result = clean_data(sample_raw_data)
        assert len(result) < len(sample_raw_data)
        assert result["trip_id"].duplicated().sum() == 0

    def test_removes_nulls(self, sample_raw_data):
        result = clean_data(sample_raw_data)
        assert result["car_id"].isna().sum() == 0

class TestParseDatetime:
    def test_valid_dates(self, sample_raw_data):
        cleaned = clean_data(sample_raw_data)
        result = parse_datetime(cleaned.copy())
        assert pd.api.types.is_datetime64_any_dtype(result["start_time"])

    def test_invalid_dates_dropped(self, sample_raw_data):
        cleaned = clean_data(sample_raw_data)
        result = parse_datetime(cleaned.copy())
        assert result["start_time"].isna().sum() == 0

class TestCalculateDuration:
    def test_duration_correct(self):
        df = pd.DataFrame({
            "start_time": pd.to_datetime(["2026-09-30 08:00:00"]),
            "end_time": pd.to_datetime(["2026-09-30 08:45:00"]),
        })
        result = calculate_duration(df)
        assert result["duration_minutes"].iloc[0] == 45.0

class TestCalculateCost:
    def test_cost_calculation(self):
        df = pd.DataFrame({
            "duration_minutes": [60.0],
            "distance_km": [20.0],
        })
        result = calculate_cost(df, base_rate=15.0)
        expected = 60.0 * 15.0 + 20.0 * 8.0
        assert result["total_cost"].iloc[0] == round(expected, 2)

class TestTransform:
    def test_full_transform(self, sample_raw_data, sample_config):
        result = transform(sample_raw_data.copy(), sample_config)
        assert len(result) > 0
        assert "duration_minutes" in result.columns
        assert "total_cost" in result.columns
        assert result["duration_minutes"].min() >= sample_config["validation"]["min_trip_duration_minutes"]
