\
# FinTech Transaction Analytics Pipeline

End-to-end пайплайн для обработки транзакций финтех-платформы: извлечение данных (API + batch), очистка, обогащение, загрузка в PostgreSQL (звёздная схема), проверки качества данных и оркестрация через Airflow DAG.

## Сценарий

Платформа обрабатывает транзакции пользователей (переводы, платежи, пополнения). Ежедневно нужно:

1. Забрать новые транзакции из «API» (имитация через генератор).
2. Очистить и обогатить данные (приведение типов, дедупликация, расчёт комиссий).
3. Загрузить в хранилище (PostgreSQL, звёздная схема).
4. Проверить качество данных (Data Quality checks).
5. Построить агрегированные витрины для аналитики.
6. Оркестрировать весь процесс через Airflow.

## Архитектура

```
[Generator/API] → [Extract] → [Transform] → [Load to PostgreSQL] → [Data Quality] → [Aggregations]
     ↑                                                              ↓
[Airflow DAG] ──────────────────────────────────────────────────── → [Alerts/Logs]
```

## Навыки Data Engineer, которые показывает проект

| Категория | Технологии |
|---|---|
| Оркестрация | Apache Airflow DAG, XCom, сенсоры, ретраи |
| ETL/ELT | Python, pandas, SQL-трансформации |
| Хранилище | PostgreSQL, звёздная схема, витрины |
| Data Quality | Проверки: row count, NULL, диапазоны, дубликаты |
| Инфраструктура | Docker Compose, изоляция, volumes |
| Тестирование | pytest, фикстуры, моки |
| Документация | ER-диаграмма (Mermaid), data dictionary, lineage |
| Конфигурация | YAML-конфиги, .env, разделение сред |

## Структура репозитория

```
fintech_pipeline/
├── dags/
│   └── transaction_pipeline_dag.py    # Airflow DAG
├── src/
│   ├── extract/
│   │   └── extractor.py                # Извлечение данных (API/batch)
│   ├── transform/
│   │   └── transformer.py              # Очистка, дедупликация, обогащение
│   ├── load/
│   │   └── loader.py                    # Загрузка в PostgreSQL
│   └── utils/
│       ├── logger.py                   # Логирование
│       ├── db.py                        # Подключение к БД
│       └── config.py                    # Загрузка конфигурации
├── sql/
│   ├── migrations/
│   │   └── schema.sql                  # DDL: звёздная схема
│   ├── seeds/
│   │   ├── seed_users.sql              # Тестовые пользователи
│   │   └── seed_merchants.sql          # Тестовые мерчанты
│   └── queries/
│       └── analytics.sql               # Аналитические запросы
├── config/
│   ├── settings.yaml                   # Параметры пайплайна
│   └── dq_rules.yaml                   # Правила Data Quality
├── tests/
│   ├── test_transformer.py            # Тесты трансформаций
│   └── test_extractor.py              # Тесты извлечения
├── data/
│   ├── raw/                            # Сырые данные (не коммитить)
│   └── sample/                         # Тестовые данные
├── docker-compose.yml                 # PostgreSQL + Airflow
├── Dockerfile                         # Образ для Airflow workers
├── requirements.txt
├── .env.example
├── .gitignore
└── README.md
```

## ER-диаграмма (звёздная схема)

```mermaid
erDiagram
    DIM_USERS {
        int user_id PK
        varchar first_name
        varchar last_name
        varchar email
        varchar tier
        date registered_at
    }

    DIM_MERCHANTS {
        int merchant_id PK
        varchar name
        varchar category
        varchar country
    }

    DIM_TIME {
        date date_id PK
        int year
        int month
        int day
        varchar weekday
    }

    FCT_TRANSACTIONS {
        int transaction_id PK
        int user_id FK
        int merchant_id FK
        date date_id FK
        decimal amount
        decimal fee
        varchar tx_type
        varchar status
        timestamp created_at
    }

    DIM_USERS ||--o{ FCT_TRANSACTIONS : "makes"
    DIM_MERCHANTS ||--o{ FCT_TRANSACTIONS : "receives"
    DIM_TIME ||--o{ FCT_TRANSACTIONS : "occurs on"
```

## Быстрый старт

### Вариант 1: Docker Compose (рекомендуется)

```bash
cp .env.example .env
docker-compose up -d
```

После запуска:
- PostgreSQL: `localhost:5432` (db: fintech, user: postgres, pass: secret)
- Airflow UI: `http://localhost:8080` (user: admin, pass: admin)

Инициализация БД:
```bash
docker exec fintech-pg psql -U postgres -d fintech -f /sql/migrations/schema.sql
docker exec fintech-pg psql -U postgres -d fintech -f /sql/seeds/seed_users.sql
docker exec fintech-pg psql -U postgres -d fintech -f /sql/seeds/seed_merchants.sql
```

### Вариант 2: Локально

```bash
pip install -r requirements.txt
python -m src.extract.extractor --date 2026-10-02
python -m src.transform.transformer
python -m src.load.loader
```

### Запуск тестов

```bash
pytest tests/ -v
```

## Data Quality

Правила описаны в `config/dq_rules.yaml`:

| Проверка | Описание |
|---|---|
| `row_count_min` | Минимум 1 строка в `fct_transactions` |
| `no_null_amount` | Поле `amount` не может быть NULL |
| `fee_range` | Комиссия в диапазоне 0–100 |
| `no_duplicate_tx` | Нет дубликатов по `transaction_id` |
| `valid_status` | `status` ∈ {completed, pending, failed} |

## Аналитические витрины

В `sql/queries/analytics.sql`:

1. **Сумма транзакций по дням** — для трендового отчёта.
2. **Топ-5 мерчантов по объёму** — для партнёрского отчёта.
3. **Средний чек по типам транзакций** — для продуктового анализа.
4. **Активность пользователей по месяцам** — для retention.

## Лицензия

MIT License. Свободно используйте для портфолио и обучения.
