"""Airflow DAG: FinTech Transaction Analytics Pipeline.

Оркестрирует ETL-пайплайн:
1. extract — извлечение транзакций
2. transform — очистка и обогащение
3. load — загрузка в PostgreSQL
4. dq_check — проверка качества данных
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator

import sys
sys.path.insert(0, "/opt/airflow/fintech_pipeline")

from src.extract.extractor import extract
from src.transform.transformer import transform
from src.load.loader import load


default_args = {
    "owner": "data_engineer",
    "depends_on_past": False,
    "retries": 3,
    "retry_delay": timedelta(minutes=5),
}

dag = DAG(
    dag_id="fintech_transaction_pipeline",
    default_args=default_args,
    description="ETL pipeline for fintech transactions",
    schedule_interval="@daily",
    start_date=datetime(2026, 1, 1),
    catchup=False,
    tags=["fintech", "etl", "data_engineer"],
)


def _extract(**context):
    ds = context["ds"]
    path = extract(date_str=ds, count=200)
    context["ti"].xcom_push(key="raw_path", value=path)


def _transform(**context):
    raw_path = context["ti"].xcom_pull(key="raw_path")
    path = transform(input_path=raw_path)
    context["ti"].xcom_push(key="transformed_path", value=path)


def _load_and_dq(**context):
    transformed_path = context["ti"].xcom_pull(key="transformed_path")
    success = load(input_path=transformed_path)
    if not success:
        raise ValueError("Data Quality checks failed!")


t_extract = PythonOperator(
    task_id="extract_transactions",
    python_callable=_extract,
    dag=dag,
)

t_transform = PythonOperator(
    task_id="transform_transactions",
    python_callable=_transform,
    dag=dag,
)

t_load = PythonOperator(
    task_id="load_and_dq",
    python_callable=_load_and_dq,
    dag=dag,
)

t_extract >> t_transform >> t_load
