# Словарь данных

## dim_users

| Поле | Тип | Описание |
|---|---|---|
| user_id | INT PK | Уникальный идентификатор пользователя |
| first_name | VARCHAR(50) | Имя |
| last_name | VARCHAR(50) | Фамилия |
| email | VARCHAR(100) | Email (уникальный) |
| tier | VARCHAR(20) | Тариф: standard / premium |
| registered_at | DATE | Дата регистрации |

## dim_merchants

| Поле | Тип | Описание |
|---|---|---|
| merchant_id | INT PK | Уникальный идентификатор мерчанта |
| name | VARCHAR(100) | Название |
| category | VARCHAR(50) | Категория: grocery, electronics, food, health, transport |
| country | VARCHAR(2) | Код страны (ISO 3166-1 alpha-2) |

## dim_time

| Поле | Тип | Описание |
|---|---|---|
| date_id | DATE PK | Дата |
| year | INT | Год |
| month | INT | Месяц (1–12) |
| day | INT | День (1–31) |
| weekday | VARCHAR(10) | День недели |

## fct_transactions

| Поле | Тип | Описание |
|---|---|---|
| transaction_id | VARCHAR(36) PK | Уникальный ID транзакции (UUID) |
| user_id | INT FK | Ссылка на dim_users |
| merchant_id | INT FK | Ссылка на dim_merchants |
| date_id | DATE FK | Ссылка на dim_time |
| amount | DECIMAL(12,2) | Сумма транзакции |
| fee | DECIMAL(12,2) | Комиссия (рассчитывается по типу) |
| tx_type | VARCHAR(20) | Тип: transfer / payment / topup |
| status | VARCHAR(20) | Статус: completed / pending / failed |
| created_at | TIMESTAMP | Время создания транзакции |
| loaded_at | TIMESTAMP | Время загрузки в DWH (DEFAULT NOW()) |

## Правила расчёта комиссии

| Тип транзакции | Ставка комиссии |
|---|---|
| transfer | 1.5% |
| payment | 1.0% |
| topup | 0% |
