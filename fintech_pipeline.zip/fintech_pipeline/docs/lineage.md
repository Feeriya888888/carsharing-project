# Lineage (происхождение данных)

## Поток данных

```
[API / Generator]
      ↓
extract/extractor.py → data/raw/transactions_YYYY-MM-DD.csv
      ↓
transform/transformer.py → data/sample/transformed/transformed_transactions.csv
      ↓
load/loader.py → PostgreSQL (fct_transactions, dim_time)
      ↓
Data Quality checks (config/dq_rules.yaml)
      ↓
sql/queries/analytics.sql → Аналитические витрины
```

## Зависимости таблиц

| Витрина | Источник |
|---|---|
| dim_users | seed_users.sql (начальные данные) |
| dim_merchants | seed_merchants.sql (начальные данные) |
| dim_time | Автогенерация из fct_transactions.date_id |
| fct_transactions | transformed_transactions.csv (extract → transform) |
| Аналитика | fct_transactions + dim_time + dim_merchants + dim_users |
