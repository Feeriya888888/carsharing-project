-- ============================================================
-- FinTech Transaction Analytics — DDL (Star Schema)
-- ============================================================

DROP TABLE IF EXISTS fct_transactions CASCADE;
DROP TABLE IF EXISTS dim_users CASCADE;
DROP TABLE IF EXISTS dim_merchants CASCADE;
DROP TABLE IF EXISTS dim_time CASCADE;

-- --------------------------------------------------------
-- DIM_TIME
-- --------------------------------------------------------
CREATE TABLE dim_time (
    date_id  DATE PRIMARY KEY,
    year     INT NOT NULL,
    month    INT NOT NULL,
    day      INT NOT NULL,
    weekday  VARCHAR(10) NOT NULL
);

-- --------------------------------------------------------
-- DIM_USERS
-- --------------------------------------------------------
CREATE TABLE dim_users (
    user_id       INT PRIMARY KEY,
    first_name    VARCHAR(50) NOT NULL,
    last_name     VARCHAR(50) NOT NULL,
    email         VARCHAR(100) NOT NULL UNIQUE,
    tier          VARCHAR(20) DEFAULT 'standard',
    registered_at DATE NOT NULL
);

-- --------------------------------------------------------
-- DIM_MERCHANTS
-- --------------------------------------------------------
CREATE TABLE dim_merchants (
    merchant_id INT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    category    VARCHAR(50) NOT NULL,
    country     VARCHAR(2) NOT NULL DEFAULT 'RU'
);

-- --------------------------------------------------------
-- FCT_TRANSACTIONS
-- --------------------------------------------------------
CREATE TABLE fct_transactions (
    transaction_id VARCHAR(36) PRIMARY KEY,
    user_id        INT NOT NULL REFERENCES dim_users(user_id),
    merchant_id    INT NOT NULL REFERENCES dim_merchants(merchant_id),
    date_id        DATE NOT NULL REFERENCES dim_time(date_id),
    amount         DECIMAL(12,2) NOT NULL,
    fee            DECIMAL(12,2) NOT NULL DEFAULT 0,
    tx_type        VARCHAR(20) NOT NULL,
    status         VARCHAR(20) NOT NULL,
    created_at     TIMESTAMP NOT NULL,
    loaded_at      TIMESTAMP DEFAULT NOW()
);

-- Индексы для аналитики
CREATE INDEX idx_fct_tx_date ON fct_transactions(date_id);
CREATE INDEX idx_fct_tx_user ON fct_transactions(user_id);
CREATE INDEX idx_fct_tx_merchant ON fct_transactions(merchant_id);
CREATE INDEX idx_fct_tx_status ON fct_transactions(status);
