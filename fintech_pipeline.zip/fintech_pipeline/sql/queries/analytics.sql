-- ============================================================
-- Аналитические запросы к витринам
-- ============================================================

-- 1. Сумма транзакций по дням (тренд)
SELECT
    t.date_id,
    t.weekday,
    COUNT(*)          AS total_tx,
    SUM(f.amount)     AS total_amount,
    SUM(f.fee)        AS total_fee
FROM fct_transactions f
JOIN dim_time t ON f.date_id = t.date_id
WHERE f.status = 'completed'
GROUP BY t.date_id, t.weekday
ORDER BY t.date_id;

-- 2. Топ-5 мерчантов по объёму
SELECT
    m.name,
    m.category,
    COUNT(*)          AS tx_count,
    SUM(f.amount)     AS total_volume
FROM fct_transactions f
JOIN dim_merchants m ON f.merchant_id = m.merchant_id
WHERE f.status = 'completed'
GROUP BY m.name, m.category
ORDER BY total_volume DESC
LIMIT 5;

-- 3. Средний чек по типам транзакций
SELECT
    f.tx_type,
    COUNT(*)                  AS tx_count,
    ROUND(AVG(f.amount), 2)   AS avg_amount,
    ROUND(AVG(f.fee), 2)      AS avg_fee,
    ROUND(SUM(f.fee), 2)      AS total_fee
FROM fct_transactions f
GROUP BY f.tx_type
ORDER BY avg_amount DESC;

-- 4. Активность пользователей по месяцам (retention)
SELECT
    t.year,
    t.month,
    COUNT(DISTINCT f.user_id) AS active_users,
    COUNT(*)                  AS total_tx,
    SUM(f.amount)             AS total_amount
FROM fct_transactions f
JOIN dim_time t ON f.date_id = t.date_id
WHERE f.status = 'completed'
GROUP BY t.year, t.month
ORDER BY t.year, t.month;

-- 5. Конверсия по статусам
SELECT
    status,
    COUNT(*)                       AS count,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct
FROM fct_transactions
GROUP BY status
ORDER BY count DESC;
