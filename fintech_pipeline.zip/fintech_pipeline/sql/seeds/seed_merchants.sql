-- Тестовые мерчанты
INSERT INTO dim_merchants (merchant_id, name, category, country) VALUES
(1, 'Supermarket Plus',  'grocery',     'RU'),
(2, 'TechStore',         'electronics', 'RU'),
(3, 'CafeCentral',       'food',        'RU'),
(4, 'Pharmacy24',        'health',      'RU'),
(5, 'FuelGo',            'transport',   'RU')
ON CONFLICT (merchant_id) DO NOTHING;
