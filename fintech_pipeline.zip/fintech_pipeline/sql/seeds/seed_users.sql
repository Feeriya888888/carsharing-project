-- Тестовые пользователи
INSERT INTO dim_users (user_id, first_name, last_name, email, tier, registered_at) VALUES
(1,  'Ivan',   'Petrov',    'ivan.petrov@example.com',     'premium',  '2025-01-15'),
(2,  'Anna',   'Sidorova',  'anna.sidorova@example.com',   'standard','2025-03-22'),
(3,  'Dmitry', 'Kozlov',    'dmitry.kozlov@example.com',   'premium',  '2025-02-10'),
(4,  'Elena',  'Morozova',  'elena.morozova@example.com',  'standard', '2025-05-01'),
(5,  'Sergey', 'Volkov',    'sergey.volkov@example.com',   'standard', '2025-06-18'),
(6,  'Olga',   'Zaitseva',  'olga.zaitseva@example.com',   'premium',  '2025-04-03'),
(7,  'Pavel',  'Smirnov',   'pavel.smirnov@example.com',   'standard', '2025-07-12'),
(8,  'Maria',  'Ivanova',   'maria.ivanova@example.com',    'standard', '2025-08-25'),
(9,  'Andrey', 'Fedorov',   'andrey.fedorov@example.com',  'premium',  '2025-01-30'),
(10, 'Nina',   'Pavlova',   'nina.pavlova@example.com',     'standard', '2025-09-05')
ON CONFLICT (user_id) DO NOTHING;
