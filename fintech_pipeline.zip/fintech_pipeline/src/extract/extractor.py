"""Extract: извлечение транзакций из API (имитация генератором) или CSV.

Если API недоступен — генерирует синтетические данные для демо/тестов.
"""

import argparse
import json
import random
import uuid
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from src.utils.config import load_settings
from src.utils.logger import setup_logger

logger = setup_logger("extractor")

TX_TYPES = ["transfer", "payment", "topup"]
STATUSES = ["completed", "pending", "failed"]
MERCHANT_IDS = [1, 2, 3, 4, 5]
USER_IDS = list(range(1, 11))


def generate_synthetic_transactions(count: int = 100) -> list[dict]:
    """Сгенерировать синтетические транзакции для демо."""
    rows = []
    for _ in range(count):
        rows.append({
            "transaction_id": str(uuid.uuid4()),
            "user_id": random.choice(USER_IDS),
            "merchant_id": random.choice(MERCHANT_IDS),
            "amount": round(random.uniform(10.0, 5000.0), 2),
            "tx_type": random.choice(TX_TYPES),
            "status": random.choices(STATUSES, weights=[80, 15, 5])[0],
            "created_at": datetime.now(timezone.utc).isoformat(),
            "raw_payload": json.dumps({"source": "synthetic"}),
        })
    return rows


def extract(date_str: str | None = None, count: int = 100) -> str:
    """Извлечь транзакции и сохранить в CSV. Возвращает путь к файлу."""
    settings = load_settings()
    output_dir = Path(settings["extract"]["output_path"])
    output_dir.mkdir(parents=True, exist_ok=True)

    date_part = date_str or datetime.now().strftime("%Y-%m-%d")
    filename = f"transactions_{date_part}.csv"
    output_path = output_dir / filename

    logger.info("Extracting transactions for date=%s, count=%d", date_part, count)

    try:
        import requests
        api_url = settings["extract"]["api_url"]
        resp = requests.get(api_url, timeout=settings["extract"]["api_timeout_seconds"])
        resp.raise_for_status()
        data = resp.json()
        logger.info("Fetched %d rows from API", len(data))
    except Exception as e:
        logger.warning("API unavailable (%s), generating synthetic data", e)
        data = generate_synthetic_transactions(count)

    df = pd.DataFrame(data)
    df.to_csv(output_path, index=False)
    logger.info("Saved %d rows to %s", len(df), output_path)
    return str(output_path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", type=str, default=None, help="Дата в формате YYYY-MM-DD")
    parser.add_argument("--count", type=int, default=100, help="Количество синтетических строк")
    args = parser.parse_args()
    extract(args.date, args.count)
