"""Load: загрузка очищенных транзакций в PostgreSQL + Data Quality checks.

Загружает в звёздную схему:
- dim_time (автоматически заполняется датами)
- fct_transactions (upsert по transaction_id)
"""

import argparse
import pandas as pd
from pathlib import Path

from src.utils.config import load_settings, load_dq_rules
from src.utils.db import get_connection, execute_query, execute_many, execute_ddl
from src.utils.logger import setup_logger

logger = setup_logger("loader")


def load_dim_time(conn, dates: list) -> None:
    """Заполнить dim_time для списка дат (если ещё нет)."""
    cur = conn.cursor()
    for d in dates:
        cur.execute(
            """INSERT INTO dim_time (date_id, year, month, day, weekday)
               VALUES (%s, %s, %s, %s, %s)
               ON CONFLICT (date_id) DO NOTHING""",
            (d, d.year, d.month, d.day, d.strftime("%A"))
        )
    conn.commit()


def load_fct_transactions(conn, df: pd.DataFrame, table: str) -> int:
    """Upsert транзакций в fct_transactions. Возвращает количество загруженных строк."""
    cur = conn.cursor()

    rows = []
    for _, r in df.iterrows():
        rows.append((
            r["transaction_id"],
            int(r["user_id"]),
            int(r["merchant_id"]),
            pd.to_datetime(r["date_id"]).date(),
            float(r["amount"]),
            float(r["fee"]),
            r["tx_type"],
            r["status"],
            pd.to_datetime(r["created_at"]),
        ))

    from psycopg2.extras import execute_values

    execute_values(
        cur,
        f"""INSERT INTO {table} (transaction_id, user_id, merchant_id, date_id, amount, fee, tx_type, status, created_at)
            VALUES %s
            ON CONFLICT (transaction_id) DO UPDATE SET
                amount = EXCLUDED.amount,
                fee = EXCLUDED.fee,
                status = EXCLUDED.status,
                created_at = EXCLUDED.created_at""",
        rows,
        page_size=1000,
    )
    conn.commit()
    logger.info("Loaded/upserted %d rows into %s", len(rows), table)
    return len(rows)


def run_dq_checks(conn, rules: list) -> bool:
    """Выполнить проверки Data Quality. Возвращает True, если все прошли."""
    all_passed = True
    cur = conn.cursor()

    for rule in rules:
        sql = rule["rule"].format(table=rule["table"])
        cur.execute(sql)
        result = cur.fetchone()[0]

        passed = True
        if "min_value" in rule and result < rule["min_value"]:
            passed = False
        if "max_value" in rule and result > rule["max_value"]:
            passed = False

        status_str = "PASS" if passed else "FAIL"
        if not passed:
            all_passed = False
            logger.error("DQ FAIL: %s | value=%s | rule=%s", rule["name"], result, rule["rule"])
        else:
            logger.info("DQ PASS: %s | value=%s", rule["name"], result)

    return all_passed


def load(input_path: str | None = None) -> bool:
    """Загрузить трансформированные данные в БД и проверить качество."""
    settings = load_settings()
    if input_path is None:
        input_path = str(Path(settings["transform"]["output_path"]) / "transformed_transactions.csv")

    logger.info("Loading transformed data from %s", input_path)
    df = pd.read_csv(input_path)

    conn = get_connection()
    try:
        # Загрузка dim_time
        dates = pd.to_datetime(df["date_id"]).dt.date.unique()
        load_dim_time(conn, list(dates))

        # Загрузка fct_transactions
        loaded = load_fct_transactions(conn, df, settings["load"]["table_facts"])
        logger.info("Loaded %d transactions", loaded)

        # Data Quality
        rules = load_dq_rules()
        dq_passed = run_dq_checks(conn, rules)

        if dq_passed:
            logger.info("All Data Quality checks passed")
        else:
            logger.error("Some Data Quality checks failed!")
            return False

        return True
    finally:
        conn.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=str, default=None)
    args = parser.parse_args()
    success = load(args.input)
    exit(0 if success else 1)
