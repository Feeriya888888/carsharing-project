"""Transform: очистка, дедупликация, обогащение транзакций.

Этапы:
1. Загрузка сырого CSV.
2. Приведение типов.
3. Удаление дубликатов по transaction_id.
4. Удаление строк с NULL в обязательных полях.
5. Расчёт комиссии (fee) по типу транзакции.
6. Фильтрация аномалий (amount <= 0 или > 100000).
7. Сохранение в очищенный CSV.
"""

import argparse
from pathlib import Path

import pandas as pd

from src.utils.config import load_settings
from src.utils.logger import setup_logger

logger = setup_logger("transformer")

FEE_RATES = {
    "transfer": 0.015,
    "payment": 0.01,
    "topup": 0.0,
}


def clean(df: pd.DataFrame) -> pd.DataFrame:
    """Очистка и обогащение DataFrame."""
    initial_count = len(df)

    # 1. Приведение типов
    df["amount"] = pd.to_numeric(df["amount"], errors="coerce")
    df["user_id"] = pd.to_numeric(df["user_id"], errors="coerce").astype("Int64")
    df["merchant_id"] = pd.to_numeric(df["merchant_id"], errors="coerce").astype("Int64")
    df["created_at"] = pd.to_datetime(df["created_at"], errors="coerce")

    # 2. Удаление дубликатов
    before_dedup = len(df)
    df = df.drop_duplicates(subset=["transaction_id"])
    after_dedup = len(df)
    logger.info("Removed %d duplicates", before_dedup - after_dedup)

    # 3. Удаление NULL в обязательных полях
    df = df.dropna(subset=["transaction_id", "user_id", "amount", "tx_type", "status"])

    # 4. Фильтрация аномалий
    df = df[(df["amount"] > 0) & (df["amount"] <= 100000)]

    # 5. Расчёт комиссии
    df["fee"] = df["amount"] * df["tx_type"].map(FEE_RATES).fillna(0)
    df["fee"] = df["fee"].round(2)

    # 6. Парсинг даты для звёздной схемы
    df["date_id"] = pd.to_datetime(df["created_at"]).dt.date

    logger.info("Cleaned: %d → %d rows (removed %d)", initial_count, len(df), initial_count - len(df))
    return df


def transform(input_path: str | None = None) -> str:
    """Трансформировать сырые данные. Возвращает путь к очищенному файлу."""
    settings = load_settings()
    in_dir = Path(settings["transform"]["input_path"])
    out_dir = Path(settings["transform"]["output_path"])
    out_dir.mkdir(parents=True, exist_ok=True)

    if input_path:
        files = [Path(input_path)]
    else:
        files = list(in_dir.glob("transactions_*.csv"))

    if not files:
        logger.error("No input files found in %s", in_dir)
        raise FileNotFoundError(f"No CSV files in {in_dir}")

    frames = []
    for f in files:
        logger.info("Reading %s", f)
        frames.append(pd.read_csv(f))

    df_raw = pd.concat(frames, ignore_index=True)
    df_clean = clean(df_raw)

    out_path = out_dir / "transformed_transactions.csv"
    df_clean.to_csv(out_path, index=False)
    logger.info("Saved %d rows to %s", len(df_clean), out_path)
    return str(out_path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=str, default=None)
    args = parser.parse_args()
    transform(args.input)
