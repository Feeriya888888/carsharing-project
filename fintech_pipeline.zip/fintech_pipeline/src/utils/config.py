"""Загрузка конфигурации из YAML-файлов и переменных окружения."""

import os
import yaml
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent


def load_settings() -> dict:
    """Загрузить основной конфиг settings.yaml."""
    path = PROJECT_ROOT / "config" / "settings.yaml"
    with open(path) as f:
        return yaml.safe_load(f)


def load_dq_rules() -> list:
    """Загрузить правила Data Quality из dq_rules.yaml."""
    path = PROJECT_ROOT / "config" / "dq_rules.yaml"
    with open(path) as f:
        return yaml.safe_load(f)["data_quality"]


def get_db_config() -> dict:
    """Получить параметры подключения к БД из переменных окружения."""
    return {
        "host": os.getenv("POSTGRES_HOST", "localhost"),
        "port": int(os.getenv("POSTGRES_PORT", "5432")),
        "dbname": os.getenv("POSTGRES_DB", "fintech"),
        "user": os.getenv("POSTGRES_USER", "postgres"),
        "password": os.getenv("POSTGRES_PASSWORD", "secret"),
    }
