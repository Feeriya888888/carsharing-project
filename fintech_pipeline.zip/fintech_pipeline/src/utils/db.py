"""Подключение к PostgreSQL и выполнение запросов."""

import psycopg2
from psycopg2.extras import execute_values
from typing import Optional

from src.utils.config import get_db_config


def get_connection():
    """Создать подключение к PostgreSQL."""
    cfg = get_db_config()
    return psycopg2.connect(**cfg)


def execute_query(sql: str, params: Optional[tuple] = None) -> list:
    """Выполнить SELECT и вернуть строки."""
    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.execute(sql, params or ())
        return cur.fetchall()
    finally:
        conn.close()


def execute_many(sql: str, rows: list, page_size: int = 1000) -> int:
    """Массовая вставка через execute_values. Возвращает количество строк."""
    conn = get_connection()
    try:
        cur = conn.cursor()
        execute_values(cur, sql, rows, page_size=page_size)
        conn.commit()
        return len(rows)
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def execute_ddl(sql: str) -> None:
    """Выполнить DDL (CREATE/DROP/ALTER)."""
    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.execute(sql)
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
