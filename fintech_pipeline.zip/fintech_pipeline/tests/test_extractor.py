"""Тесты для экстрактора."""

import pytest
import pandas as pd
from pathlib import Path

from src.extract.extractor import generate_synthetic_transactions, extract


def test_generate_synthetic_count():
    """Генератор должен вернуть ровно count записей."""
    data = generate_synthetic_transactions(count=50)
    assert len(data) == 50
    assert all("transaction_id" in row for row in data)


def test_generate_synthetic_types():
    """Типы транзакций должны быть из допустимого набора."""
    data = generate_synthetic_transactions(count=20)
    tx_types = {row["tx_type"] for row in data}
    assert tx_types.issubset({"transfer", "payment", "topup"})


def test_generate_synthetic_statuses():
    """Статусы должны быть из допустимого набора."""
    data = generate_synthetic_transactions(count=20)
    statuses = {row["status"] for row in data}
    assert statuses.issubset({"completed", "pending", "failed"})


def test_extract_creates_csv(tmp_path, monkeypatch):
    """extract() должен создать CSV-файл."""
    from src.utils.config import load_settings
    settings = load_settings()
    monkeypatch.setitem(
        settings["extract"],
        "output_path",
        str(tmp_path / "raw")
    )
    monkeypatch.setattr(
        "src.extract.extractor.load_settings",
        lambda: settings
    )
    path = extract(date_str="2026-01-01", count=10)
    assert Path(path).exists()
    df = pd.read_csv(path)
    assert len(df) == 10
    assert "transaction_id" in df.columns
