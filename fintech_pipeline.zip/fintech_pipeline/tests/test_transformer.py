"""Тесты для трансформера."""

import pytest
import pandas as pd
import numpy as np
from pathlib import Path

from src.transform.transformer import clean, FEE_RATES


@pytest.fixture
def sample_df():
    """DataFrame с валидными и невалидными строками."""
    return pd.DataFrame([
        {
            "transaction_id": "tx-001",
            "user_id": 1,
            "merchant_id": 1,
            "amount": 100.0,
            "tx_type": "transfer",
            "status": "completed",
            "created_at": "2026-01-01T10:00:00Z",
        },
        {
            "transaction_id": "tx-002",
            "user_id": 2,
            "merchant_id": 2,
            "amount": 500.0,
            "tx_type": "payment",
            "status": "completed",
            "created_at": "2026-01-01T11:00:00Z",
        },
        # Дубликат tx-001
        {
            "transaction_id": "tx-001",
            "user_id": 1,
            "merchant_id": 1,
            "amount": 100.0,
            "tx_type": "transfer",
            "status": "completed",
            "created_at": "2026-01-01T10:00:00Z",
        },
        # Аномалия: amount = 0
        {
            "transaction_id": "tx-003",
            "user_id": 3,
            "merchant_id": 3,
            "amount": 0,
            "tx_type": "topup",
            "status": "failed",
            "created_at": "2026-01-01T12:00:00Z",
        },
        # NULL в обязательном поле
        {
            "transaction_id": "tx-004",
            "user_id": None,
            "merchant_id": 4,
            "amount": 200.0,
            "tx_type": "payment",
            "status": "pending",
            "created_at": "2026-01-01T13:00:00Z",
        },
    ])


def test_clean_removes_duplicates(sample_df):
    """Дубликаты по transaction_id должны быть удалены."""
    result = clean(sample_df)
    assert len(result) == 2
    assert result["transaction_id"].nunique() == 2


def test_clean_removes_nulls(sample_df):
    """Строки с NULL в user_id должны быть удалены."""
    result = clean(sample_df)
    assert "tx-004" not in result["transaction_id"].values


def test_clean_removes_anomalies(sample_df):
    """Строки с amount <= 0 должны быть удалены."""
    result = clean(sample_df)
    assert (result["amount"] > 0).all()


def test_clean_calculates_fee(sample_df):
    """Комиссия должна считаться по ставке для каждого типа."""
    result = clean(sample_df)
    for _, row in result.iterrows():
        expected_fee = round(row["amount"] * FEE_RATES[row["tx_type"]], 2)
        assert abs(row["fee"] - expected_fee) < 0.01


def test_clean_adds_date_id(sample_df):
    """Должно появиться поле date_id."""
    result = clean(sample_df)
    assert "date_id" in result.columns


def test_clean_fee_topup_is_zero():
    """Пополнение (topup) — без комиссии."""
    df = pd.DataFrame([{
        "transaction_id": "tx-topup",
        "user_id": 1,
        "merchant_id": 1,
        "amount": 1000.0,
        "tx_type": "topup",
        "status": "completed",
        "created_at": "2026-01-01T10:00:00Z",
    }])
    result = clean(df)
    assert result.iloc[0]["fee"] == 0.0
